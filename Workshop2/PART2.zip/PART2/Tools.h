#ifndef SDDS_TOOLS_H_
#define SDDS_TOOLS_H_

namespace sdds {
	void strCpy(char* des, const char* src);
}
#endif 


